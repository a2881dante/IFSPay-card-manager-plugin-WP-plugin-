<?php

define('COMPONENT_BALANCE_DIR', get_template_directory() . '/components/balance');
define("WDCS_MAIN_URL", "https://www.cardportal.com");
define('WDCS_COOKIE_PATH', COMPONENT_BALANCE_DIR . '/cookie');

?>
